# Geode TEST launcher for Geometry Dash Android 2.2091

This is a test fork of the official Geode Android launcher source.

Changes:
- Application ID: `com.geode.launcher.test` (installs alongside the official `com.geode.launcher`).
- App label: `Geode TEST 2.2091`.
- Launcher support target: Geometry Dash Android version code `43`, unified version `2.2091`.
- GitHub Actions workflow builds an unsigned-debug APK without signing secrets.

Build:
1. Upload this source tree to a new GitHub repository.
2. Open Actions -> "Build Geode TEST for GD 2.2091" -> Run workflow.
3. Download artifact `geode-test-android-2.2091`, then install the APK.

Important:
- This launcher does not replace the official Geode launcher package.
- Its app-specific launcher data directory is separate because the application ID differs.
- It still loads the installed Geometry Dash package `com.robtopx.geometryjump`; it is not a second copy of the Geometry Dash game.
- The original Geometry Dash installation is not repackaged or overwritten by this build. Back up game saves before testing.
- Compatibility with the current Geode loader and GD 2.2091 must be verified on-device; a successful APK build does not guarantee game launch.
